#include <iostream>
#include <string.h>
using namespace std;

// Bài 9: Hãy nối chuỗi S vào sau chuỗi T mà không sử dụng hàm có sẵn trong các thư viện của C/C++.
int main() {
    char S[100], T[100];
    
    cout << "Nhap chuoi S: ";
    cin.getline(S, 100);
    
    cout << "Nhap chuoi T: ";
    cin.getline(T, 100);
    
    int lenS = 0, lenT = 0;
    
    // Tính độ dài chuỗi S
    while (S[lenS] != '\0') {
        lenS++;
    }
    
    // Tính độ dài chuỗi T
    while (T[lenT] != '\0') {
        lenT++;
    }
    
    // Nối S vào sau T
    for (int i = 0; i < lenS; i++) {
        T[lenT + i] = S[i];
    }
    
    // Thêm ký tự kết thúc chuỗi
    T[lenT + lenS] = '\0';
    
    cout << "Chuoi sau khi noi: " << T << endl;
    
    return 0;
}
