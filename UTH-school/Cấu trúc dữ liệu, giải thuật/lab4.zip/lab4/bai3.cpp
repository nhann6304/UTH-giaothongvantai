#include <iostream>
#include <algorithm>
using namespace std;

// Bài 3: Cho dãy số nguyên a và số nguyên x nhập từ bàn phím. Hãy tìm cách lấy trong a các số sao cho đảm bảo rằng tổng của chúng nhỏ hơn x và số phần tử lấy từ a càng nhiều càng tốt.
int main() {
    int n, x;
    cout << "Nhap so phan tu cua day: ";
    cin >> n;
    
    int a[n];
    cout << "Nhap " << n << " phan tu: ";
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    
    cout << "Nhap so x: ";
    cin >> x;
    
    // Sắp xếp dãy để lấy các số nhỏ nhất trước
    sort(a, a + n);
    
    int sum = 0;
    int count = 0;
    int result[n];
    int resultCount = 0;
    
    for (int i = 0; i < n; i++) {
        if (sum + a[i] < x) {
            sum += a[i];
            result[resultCount++] = a[i];
            count++;
        } else {
            break;
        }
    }
    
    cout << "So phan tu lon nhat co the lay: " << count << endl;
    cout << "Tong cua chung: " << sum << endl;
    cout << "Cac phan tu duoc lay: ";
    for (int i = 0; i < resultCount; i++) {
        cout << result[i] << " ";
    }
    cout << endl;
    
    return 0;
}
