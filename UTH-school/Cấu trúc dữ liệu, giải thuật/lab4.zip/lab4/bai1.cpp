#include <iostream>
using namespace std;

// Bài 1: Tính tổng các phần tử là số chia hết cho 3 trong dãy số nguyên gồm n phần tử
int main() {
    int n;
    cout << "Nhap so phan tu cua day: ";
    cin >> n;
    
    int a[n];
    int sum = 0;
    
    cout << "Nhap " << n << " phan tu: ";
    for (int i = 0; i < n; i++) {
        cin >> a[i];
        if (a[i] % 3 == 0) {
            sum += a[i];
        }
    }
    
    cout << "Tong cac phan tu chia het cho 3 la: " << sum << endl;
    
    return 0;
}
