#include <iostream>
#include <string.h>
#include <ctype.h>
using namespace std;

// Bài 8: Cho con trỏ xâu ký tự S bất kỳ. Hãy định dạng S sao cho không dư thừa khoảng trống ở đầu, cuối và giữa các từ chỉ chứa duy nhất 1 khoảng trống. Mỗi từ sẽ bắt đầu bằng ký tự in hoa, các ký tự còn lại là chữ in thường.
int main() {
    char s[1000];
    cout << "Nhap chuoi S: ";
    cin.getline(s, 1000);
    
    int length = strlen(s);
    char result[1000];
    int resultIndex = 0;
    int i = 0;
    
    // Bỏ khoảng trắng ở đầu
    while (i < length && s[i] == ' ') {
        i++;
    }
    
    bool newWord = true;
    
    while (i < length) {
        if (s[i] != ' ') {
            // Xử lý ký tự
            if (newWord) {
                // Ký tự đầu của từ - in hoa
                result[resultIndex++] = toupper(s[i]);
                newWord = false;
            } else {
                // Các ký tự còn lại - in thường
                result[resultIndex++] = tolower(s[i]);
            }
        } else {
            // Bỏ qua khoảng trắng thừa
            while (i < length && s[i] == ' ') {
                i++;
            }
            
            // Nếu chưa hết chuỗi, thêm một khoảng trắng
            if (i < length) {
                result[resultIndex++] = ' ';
                newWord = true;
            }
        }
        i++;
    }
    
    result[resultIndex] = '\0';
    
    cout << "Chuoi sau khi dinh dang: " << result << endl;
    
    return 0;
}
