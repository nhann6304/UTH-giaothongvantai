#include <iostream>
#include <map>
using namespace std;

// Bài 2: Hãy tìm những phần tử có giá trị trùng nhau trong dãy số nguyên n phần tử. Cho biết giá trị đó xuất hiện bao nhiêu lần.
int main() {
    int n;
    cout << "Nhap so phan tu cua day: ";
    cin >> n;
    
    int a[n];
    map<int, int> frequency;
    
    cout << "Nhap " << n << " phan tu: ";
    for (int i = 0; i < n; i++) {
        cin >> a[i];
        frequency[a[i]]++;
    }
    
    cout << "Cac phan tu trung lap va so lan xuat hien:" << endl;
    bool found = false;
    for (auto pair : frequency) {
        if (pair.second > 1) {
            cout << "Gia tri " << pair.first << " xuat hien " << pair.second << " lan" << endl;
            found = true;
        }
    }
    
    if (!found) {
        cout << "Khong co phan tu trung lap nao!" << endl;
    }
    
    return 0;
}
